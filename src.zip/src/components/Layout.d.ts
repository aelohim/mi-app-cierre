// src/components/Layout.d.ts
import { ReactNode } from 'react';

declare const Layout: React.FC<{ children: ReactNode }>;

export default Layout;